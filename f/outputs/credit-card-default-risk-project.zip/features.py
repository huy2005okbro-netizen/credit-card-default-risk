"""Feature selection and preprocessing constructed inside an sklearn Pipeline."""
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from .config import MODEL_FEATURES


def feature_columns(df):
    missing = set(MODEL_FEATURES) - set(df.columns)
    if missing:
        raise ValueError(f"Dataset does not have required serving features: {sorted(missing)}")
    return MODEL_FEATURES.copy()


def make_preprocessor(columns):
    # This dataset's retained predictors are numeric. Keeping this in a Pipeline
    # ensures imputation and scaling are fitted solely on each training partition.
    numeric = Pipeline([("impute", SimpleImputer(strategy="median")), ("scale", StandardScaler())])
    return ColumnTransformer([("numeric", numeric, columns)], remainder="drop")

