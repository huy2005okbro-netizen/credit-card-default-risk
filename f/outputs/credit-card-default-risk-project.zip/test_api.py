from fastapi.testclient import TestClient
from api.main import app


def test_health_is_available_without_a_model():
    response = TestClient(app).get("/api/health")
    assert response.status_code == 200
    assert response.json()["stores_inputs"] is False

