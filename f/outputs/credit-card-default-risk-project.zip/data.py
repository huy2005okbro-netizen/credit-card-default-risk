"""Data checks and leakage-safe splitting."""
import pandas as pd
from sklearn.model_selection import train_test_split
from .config import RAW_DATA, SEED, TARGET


def load_data(path=RAW_DATA) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError("Raw data not found. Run: python -m src.download_data")
    df = pd.read_csv(path)
    if TARGET not in df.columns:
        raise ValueError(f"Expected target column {TARGET!r}.")
    if df[TARGET].isna().any() or not set(df[TARGET].dropna().unique()).issubset({0, 1}):
        raise ValueError("Target must be binary 0/1 with no missing values.")
    if df.empty:
        raise ValueError("Dataset is empty.")
    return df


def split_data(df: pd.DataFrame):
    """Return train, validation, test frames before every learned transformation."""
    train_val, test = train_test_split(df, test_size=0.20, stratify=df[TARGET], random_state=SEED)
    train, validation = train_test_split(
        train_val, test_size=0.25, stratify=train_val[TARGET], random_state=SEED
    )
    return train.copy(), validation.copy(), test.copy()

