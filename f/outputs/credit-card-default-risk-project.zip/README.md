# Credit Card Default Risk Lab

An end-to-end, reproducible course project for screening accounts that may benefit from a payment reminder or financial-support outreach. It is **not** for automated credit denial, pricing, or penalties.

## What is included

- A data download script for UCI dataset 350.
- Train/validation/test splitting before preprocessing, with all transformations fit only on training data.
- Two baselines: always predict non-default and unweighted logistic regression.
- Main logistic-regression candidates with and without balanced class weights.
- Validation-based threshold selection using an explicit false-positive/false-negative cost ratio.
- Test-only final report with ROC-AUC, PR-AUC, recall, precision, Brier score, confusion matrix, calibration curve, and group error audit.
- FastAPI `POST /api/risk-score`, input validation, a browser UI, and a model-card template.

## Quick start

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m src.download_data
python -m src.train --cost-fn 5 --cost-fp 1
python -m src.evaluate
uvicorn api.main:app --reload
```

Open `http://127.0.0.1:8000`. The model must be trained before the API can score requests.

The interface includes three required screens in one responsive page: scope/guardrails, a risk-score simulation form, and an evaluation dashboard with a model card. It calls these local API routes:

- `GET /api/health` — model readiness; inputs are never stored.
- `GET /api/model-card` — selected model, threshold, validation metrics, and use restrictions.
- `POST /api/risk-score` — validated simulation request.

## Reproducibility rules

1. Do not put the raw dataset in Git. Run `python -m src.download_data` instead.
2. Keep the test set untouched until `python -m src.evaluate`.
3. Do not oversample before splitting. This project uses class weights inside the estimator instead.
4. Record package versions, random seed, data shape, and the cost assumptions in `reports/metrics.json`.
5. Treat `SEX`, `EDUCATION`, and `MARRIAGE` as audit-only columns by default, not model features.

## Project layout

```text
src/            download, schema checks, training, evaluation
api/            FastAPI service and browser app
models/         generated pipeline and metadata (ignored by Git)
reports/        generated metrics and plots
tests/          API and threshold tests
dist/           static project dashboard for private hosting
```

## API example

```json
POST /api/risk-score
{
  "limit_bal": 50000,
  "pay_0": 2,
  "pay_2": 2,
  "pay_3": 0,
  "pay_amt1": 1000,
  "bill_amt1": 45000
}
```

The endpoint returns a risk probability, a threshold-based outreach recommendation, the operating threshold, and a disclaimer. It does not retain inputs.

