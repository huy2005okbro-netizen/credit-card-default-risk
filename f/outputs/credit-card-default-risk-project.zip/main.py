from pathlib import Path
import json
from functools import lru_cache
import joblib
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, model_validator
from src.config import METADATA_PATH, MODEL_PATH

app = FastAPI(title="Credit Card Default Risk Lab", version="1.0.0")
ROOT = Path(__file__).resolve().parents[1]


class RiskInput(BaseModel):
    limit_bal: float = Field(ge=10000, le=1_000_000)
    pay_0: int = Field(ge=-2, le=9)
    pay_2: int = Field(ge=-2, le=9)
    pay_3: int = Field(ge=-2, le=9)
    pay_amt1: float = Field(ge=0, le=2_000_000)
    bill_amt1: float = Field(ge=-500_000, le=2_000_000)

    @model_validator(mode="after")
    def payment_is_plausible(self):
        if self.pay_amt1 > max(self.limit_bal * 10, 1_000_000):
            raise ValueError("pay_amt1 is implausibly high for the supplied credit limit")
        return self


@lru_cache(maxsize=1)
def artifact():
    if not MODEL_PATH.exists() or not METADATA_PATH.exists():
        raise HTTPException(503, "Model not trained. Run python -m src.train first.")
    return joblib.load(MODEL_PATH), json.loads(METADATA_PATH.read_text(encoding="utf-8"))


@app.get("/api/health")
def health():
    return {
        "status": "ready" if MODEL_PATH.exists() and METADATA_PATH.exists() else "training_required",
        "stores_inputs": False,
        "next_step": None if MODEL_PATH.exists() else "Run python -m src.download_data, python -m src.train, then python -m src.evaluate.",
    }


@app.get("/api/model-card")
def model_card():
    """Return only local model metadata; no user input is read or stored."""
    if not METADATA_PATH.exists():
        raise HTTPException(503, "Model card unavailable until training has completed.")
    metadata = json.loads(METADATA_PATH.read_text(encoding="utf-8"))
    return {
        "selected_model": metadata["selected_model"],
        "threshold": metadata["threshold"],
        "features": metadata["features"],
        "validation": metadata["validation"],
        "intended_use": "Prioritize voluntary payment reminders or financial-support outreach.",
        "prohibited_use": "Do not use for credit approval, pricing, penalties, or automated adverse action.",
        "stores_inputs": False,
    }


@app.post("/api/risk-score")
def risk_score(payload: RiskInput):
    model, metadata = artifact()
    # Explicitly construct a single record. Missing training features are rejected,
    # rather than silently imputed at the service boundary.
    values = {"LIMIT_BAL": payload.limit_bal, "PAY_0": payload.pay_0, "PAY_2": payload.pay_2,
              "PAY_3": payload.pay_3, "PAY_AMT1": payload.pay_amt1, "BILL_AMT1": payload.bill_amt1}
    missing = set(metadata["features"]) - set(values)
    if missing:
        raise HTTPException(422, f"Unsupported trained feature set: {sorted(missing)}")
    import pandas as pd
    probability = float(model.predict_proba(pd.DataFrame([values])[metadata["features"]])[:, 1][0])
    threshold = float(metadata["threshold"])
    return {
        "risk_probability": round(probability, 4),
        "threshold": threshold,
        "recommendation": "offer_support_outreach" if probability >= threshold else "no_outreach_flag",
        "disclaimer": "Support triage only. Do not use this output for credit approval, pricing, or penalties.",
        "stores_input": False,
    }


app.mount("/", StaticFiles(directory=ROOT / "api" / "static", html=True), name="static")

