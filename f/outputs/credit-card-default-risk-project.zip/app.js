const form = document.querySelector('#score-form');
const result = document.querySelector('#result');
const status = document.querySelector('#status');
const metrics = document.querySelector('#metrics');

async function getJson(url, options) {
  const response = await fetch(url, options);
  const body = await response.json();
  if (!response.ok) throw new Error(body.detail || 'Yêu cầu không thành công.');
  return body;
}

async function initialise() {
  try {
    const health = await getJson('/api/health');
    status.textContent = health.status === 'ready' ? 'Mô hình đã sẵn sàng · dữ liệu nhập không được lưu' : `Cần huấn luyện mô hình · ${health.next_step}`;
    status.classList.toggle('ready', health.status === 'ready');
    if (health.status !== 'ready') { metrics.innerHTML = '<p>Chạy pipeline để xem model card và metrics.</p>'; return; }
    const card = await getJson('/api/model-card');
    const validation = Object.entries(card.validation).map(([name, values]) => `<tr><td>${name}</td><td>${values.pr_auc?.toFixed(3) ?? '—'}</td><td>${values.recall?.toFixed(3) ?? '—'}</td><td>${values.threshold.toFixed(2)}</td></tr>`).join('');
    metrics.innerHTML = `<p><strong>${card.selected_model}</strong> · Ngưỡng đang dùng: <strong>${card.threshold.toFixed(2)}</strong></p><table><thead><tr><th>Mô hình</th><th>PR-AUC validation</th><th>Recall</th><th>Ngưỡng</th></tr></thead><tbody>${validation}</tbody></table><p class="hint">${card.intended_use}</p><p class="warning">${card.prohibited_use}</p>`;
  } catch (error) { status.textContent = `Không thể tải trạng thái: ${error.message}`; metrics.innerHTML = '<p>Model card chưa sẵn sàng.</p>'; }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const payload = Object.fromEntries(new FormData(form));
  Object.keys(payload).forEach(key => payload[key] = Number(payload[key]));
  result.textContent = 'Đang tính điểm…';
  try {
    const data = await getJson('/api/risk-score', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)});
    const percent = (data.risk_probability * 100).toFixed(1);
    const flagged = data.recommendation === 'offer_support_outreach';
    result.innerHTML = `<strong>${flagged ? 'Nên xem xét hỗ trợ' : 'Chưa cần gắn cờ hỗ trợ'}</strong><p>Xác suất rủi ro mô phỏng: <b>${percent}%</b> · Ngưỡng: ${(data.threshold * 100).toFixed(0)}%</p><p class="warning">${data.disclaimer}</p>`;
  } catch (error) { result.textContent = `Không thể tính điểm: ${error.message}`; }
});
initialise();

