# Model card

## Intended use

Prioritize voluntary payment reminders or financial-support outreach for educational demonstration. A human must make any follow-up decision.

## Prohibited use

Credit approval or denial, interest-rate setting, pricing, penalties, automated adverse action, or any individual high-impact decision.

## Data and target

UCI Default of Credit Card Clients (dataset 350). The target is default in the following month. Raw data is downloaded on demand and excluded from Git.

## Evaluation protocol

The data are stratified into train (60%), validation (20%), and independent test (20%) before preprocessing. Threshold selection happens only on validation. The test set is used only by `src.evaluate` for the final report.

## Limitations

This is observational data from a specific historical context. It may not generalize, does not prove causality, and can show group error disparities even when sensitive columns are excluded from training.

