"""Fit candidates on train, choose threshold/model on validation, save one pipeline."""
import argparse, json, platform
from datetime import datetime, timezone
import joblib
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import average_precision_score, brier_score_loss, precision_score, recall_score, roc_auc_score
from .config import METADATA_PATH, MODEL_DIR, MODEL_PATH, SEED, TARGET
from .data import load_data, split_data
from .features import feature_columns, make_preprocessor


def best_threshold(y, proba, cost_fn, cost_fp):
    y = np.asarray(y)
    proba = np.asarray(proba)
    candidates = [round(x / 100, 2) for x in range(5, 96, 5)]
    costs = []
    for threshold in candidates:
        pred = proba >= threshold
        fn = ((y == 1) & ~pred).sum()
        fp = ((y == 0) & pred).sum()
        costs.append(cost_fn * fn + cost_fp * fp)
    i = min(range(len(costs)), key=costs.__getitem__)
    return candidates[i], costs[i]


def scores(y, p, threshold):
    pred = p >= threshold
    return {"roc_auc": float(roc_auc_score(y, p)), "pr_auc": float(average_precision_score(y, p)),
            "recall": float(recall_score(y, pred, zero_division=0)),
            "precision": float(precision_score(y, pred, zero_division=0)),
            "brier": float(brier_score_loss(y, p))}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cost-fn", type=float, default=5.0)
    parser.add_argument("--cost-fp", type=float, default=1.0)
    args = parser.parse_args()
    df = load_data()
    train, val, test = split_data(df)
    cols = feature_columns(df)
    candidates = {}
    for name, weight in {"logistic_unweighted": None, "logistic_balanced": "balanced"}.items():
        pipe = Pipeline([("preprocess", make_preprocessor(cols)), ("model", LogisticRegression(max_iter=2000, class_weight=weight, random_state=SEED))])
        pipe.fit(train[cols], train[TARGET])
        p = pipe.predict_proba(val[cols])[:, 1]
        threshold, expected_cost = best_threshold(val[TARGET].to_numpy(), p, args.cost_fn, args.cost_fp)
        candidates[name] = {"pipeline": pipe, "threshold": threshold, "expected_cost": expected_cost, "validation": scores(val[TARGET], p, threshold), "class_weight": weight}
    chosen_name = min(candidates, key=lambda n: candidates[n]["expected_cost"])
    chosen = candidates[chosen_name]
    MODEL_DIR.mkdir(exist_ok=True)
    joblib.dump(chosen["pipeline"], MODEL_PATH)
    metadata = {"selected_model": chosen_name, "threshold": chosen["threshold"], "cost_assumptions": {"false_negative": args.cost_fn, "false_positive": args.cost_fp}, "features": cols, "seed": SEED, "split_sizes": {"train": len(train), "validation": len(val), "test": len(test)}, "validation": {k: {"threshold": v["threshold"], "expected_cost": v["expected_cost"], **v["validation"]} for k, v in candidates.items()}, "created_at": datetime.now(timezone.utc).isoformat(), "python": platform.python_version()}
    METADATA_PATH.write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(f"Saved {chosen_name} with validation threshold {chosen['threshold']:.2f}")
    print("Do not use the test set until: python -m src.evaluate")


if __name__ == "__main__":
    main()

