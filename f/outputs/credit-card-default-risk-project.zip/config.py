from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
RAW_DATA = DATA_DIR / "raw" / "uci_credit_default.csv"
MODEL_DIR = ROOT / "models"
MODEL_PATH = MODEL_DIR / "risk_pipeline.joblib"
METADATA_PATH = MODEL_DIR / "metadata.json"
REPORT_DIR = ROOT / "reports"
METRICS_PATH = REPORT_DIR / "metrics.json"
SEED = 42
TARGET = "default_next_month"

# The UCI dataset has 23 predictors. Sensitive attributes are retained only for auditing.
AUDIT_ONLY = ["SEX", "EDUCATION", "MARRIAGE"]
MODEL_FEATURES = ["LIMIT_BAL", "PAY_0", "PAY_2", "PAY_3", "PAY_AMT1", "BILL_AMT1"]

