# Run from the project folder after training the model.
python -m uvicorn api.main:app --reload
