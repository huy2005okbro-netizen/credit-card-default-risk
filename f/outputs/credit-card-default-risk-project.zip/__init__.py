"""Reproducible credit-default risk-screening pipeline."""

