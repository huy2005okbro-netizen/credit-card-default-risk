"""Download UCI dataset 350 without committing raw data to Git."""
from pathlib import Path
import pandas as pd
from ucimlrepo import fetch_ucirepo
from .config import RAW_DATA


def main() -> None:
    dataset = fetch_ucirepo(id=350)
    features = dataset.data.features.copy()
    targets = dataset.data.targets.copy()
    target_col = targets.columns[0]
    frame = pd.concat([features, targets.rename(columns={target_col: "default_next_month"})], axis=1)
    RAW_DATA.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(RAW_DATA, index=False)
    print(f"Saved {len(frame):,} rows and {len(frame.columns)} columns to {RAW_DATA}")


if __name__ == "__main__":
    main()

