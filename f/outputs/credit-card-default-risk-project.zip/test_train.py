from src.train import best_threshold


def test_threshold_prefers_recall_when_false_negatives_cost_more():
    threshold, _ = best_threshold([1, 1, 0, 0], [0.3, 0.4, 0.2, 0.1], cost_fn=10, cost_fp=1)
    assert threshold <= 0.3

