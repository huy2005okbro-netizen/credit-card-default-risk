"""Single final test evaluation, calibration data, and group audit."""
import json
import joblib
import numpy as np
from sklearn.calibration import calibration_curve
from sklearn.metrics import confusion_matrix
from .config import METADATA_PATH, METRICS_PATH, MODEL_PATH, TARGET
from .data import load_data, split_data
from .train import scores


def group_audit(frame, y, pred):
    rows = {}
    for column in ("SEX", "EDUCATION", "MARRIAGE"):
        if column not in frame:
            continue
        groups = {}
        for value in sorted(frame[column].dropna().unique()):
            mask = frame[column] == value
            groups[str(value)] = {"n": int(mask.sum()), "recall": float(((y[mask] == 1) & pred[mask]).sum() / max(1, (y[mask] == 1).sum())), "positive_rate": float(pred[mask].mean())}
        rows[column] = groups
    return rows


def main():
    if not MODEL_PATH.exists() or not METADATA_PATH.exists():
        raise FileNotFoundError("Train first: python -m src.train")
    metadata = json.loads(METADATA_PATH.read_text(encoding="utf-8"))
    _, _, test = split_data(load_data())
    model = joblib.load(MODEL_PATH)
    p = model.predict_proba(test[metadata["features"]])[:, 1]
    threshold = metadata["threshold"]
    pred = p >= threshold
    y = test[TARGET].to_numpy()
    frac_pos, mean_pred = calibration_curve(y, p, n_bins=10, strategy="quantile")
    report = {"test_used_once": True, "threshold": threshold, "metrics": scores(y, p, threshold), "confusion_matrix": confusion_matrix(y, pred).tolist(), "always_non_default_accuracy": float((y == 0).mean()), "calibration": {"mean_predicted_probability": mean_pred.tolist(), "observed_frequency": frac_pos.tolist()}, "group_audit": group_audit(test, y, pred), "limitations": ["Observational dataset: outputs do not establish causality.", "Sensitive attributes are excluded from features but audited for error differences.", "Model supports outreach prioritization only; it must not determine credit approval, pricing, or penalties."]}
    METRICS_PATH.parent.mkdir(exist_ok=True)
    METRICS_PATH.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report["metrics"], indent=2))


if __name__ == "__main__":
    main()

